"""
Populate corporate_ownership database with fake data using the SQLAlchemy ORM.
"""
from corporate_ownership.src.models import Company, Facility, Product, Supplier, db
from corporate_ownership.src import create_app

def truncate_tables():
    """Delete all rows from database tables"""
    Company.query.delete()
    Facility.query.delete()
    Product.query.delete()
    Supplier.query.delete()
    db.session.commit()

def main():
    """Main driver function"""
    app = create_app()
    app.app_context().push()
    truncate_tables()

    suppliers = [
        Supplier(supplier_name='Western Clothing Supplies'),
        Supplier(supplier_name='Eastern Clothing Supplies'),
        Supplier(supplier_name='Midwestern Clothing Supplies'),
    ]

    db.session.add_all(suppliers)
    db.session.commit()

    products = [
        Product(product_name='Jeans', supplier_id=19),
        Product(product_name='Jackets', supplier_id=19),
        Product(product_name='Coats', supplier_id=20),
        Product(product_name='Shirts', supplier_id=21),
    ]

    db.session.add_all(products)
    db.session.commit()

    facilities = [
        Facility(facility_name='Denim 4 All', facility_address='455 Main St FL USA', product_id=25),
        Facility(facility_name='Buttons, Buttons, Buttons', facility_address='456 Main St FL USA', product_id=26),
        Facility(facility_name='Zippers R Us', facility_address='457 Main St FL USA', product_id=27),
    ]

    db.session.add_all(facilities)
    db.session.commit()

    companies = [
        Company(tax_id='678549', company_name='Nordstrom', facility_id=13),
        Company(tax_id='678550', company_name='Levis', facility_id=14),
        Company(tax_id='678551', company_name='Wrangler', facility_id=15),
    ]

    db.session.add_all(companies)
    db.session.commit()

# run script
main()