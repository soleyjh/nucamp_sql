from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Company(db.Model):
    __tablename__ = 'companies'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tax_id = db.Column(db.String(128), unique=True, nullable=False)
    company_name = db.Column(db.String(128), nullable=True)
    facility_id =  db.Column(db.Integer, db.ForeignKey('facilities.id'),unique=False, nullable=True)

    def __init__(self, tax_id: str, company_name: int, facility_id: int):
        self.tax_id = tax_id
        self.company_name = company_name
        self.facility_id = facility_id

    def serialize(self):
        return {
            'id': self.id,
            'tax_id': self.tax_id,
            'company_name': self.company_name,
            'facility_id': self.facility_id
        }

class Facility(db.Model):
    __tablename__ = 'facilities'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    facility_name = db.Column(db.String(128), nullable=True)
    facility_address = db.Column(db.String(128), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'),unique=False, nullable=True)
    companies = db.relationship('Company', backref='facility')

    def __init__(self, facility_name: str, facility_address: str, product_id: int):
        self.facility_name = facility_name
        self.facility_address = facility_address
        self.product_id = product_id

    def serialize(self):
        return {
            'id': self.id,
            'facility_name': self.facility_name,
            'facility_address': self.facility_address,
            'product_id': self.product_id
        }

class Product(db.Model):
    __tablename__ = 'products'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    product_name = db.Column(db.String(128), nullable=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey('suppliers.id'),unique=False, nullable=True)
    facilities = db.relationship('Facility', backref='product')

    def __init__(self, product_name: str, supplier_id: int):
        self.product_name = product_name
        self.supplier_id = supplier_id

    def serialize(self):
        return {
            'id': self.id,
            'product_name': self.product_name,
            'supplier_id': self.supplier_id
        }

class Supplier(db.Model):
    __tablename__ = 'suppliers'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    supplier_name = db.Column(db.String(128), unique=True, nullable=False)
    companies = db.relationship('Product', backref='supplier')

    def __init__(self, supplier_name: str):
        self.supplier_name = supplier_name

    def serialize(self):
        return {
            'id': self.id,
            'supplier_name': self.supplier_name
        }