from flask import Blueprint, jsonify, abort, request
from ..models import Company, Facility, Supplier, Product, db

bp = Blueprint('companies', __name__, url_prefix='/companies')

@bp.route('', methods=['GET']) # decorator takes path and list of HTTP verbs
def index():
    companies = Company.query.all() # ORM performs SELECT query
    result = []
    for c in companies:
        result.append(c.serialize()) # build list of Tweets as dictionaries
    return jsonify(result) # return JSON response

@bp.route('/<int:id>', methods=['GET'])
def show(id: int):
    c = Company.query.get_or_404(id)
    return jsonify(c.serialize())

@bp.route('', methods=['POST'])
def create():
    # req body must contain user_id and content
    if 'tax_id' not in request.json or 'company_name' not in request.json or 'facility_id' not in request.json:
        return abort(400)
    # construct Tweet
    c = Company(
        tax_id=request.json['tax_id'],
        company_name=request.json['company_name'],
        facility_id=request.json['facility_id']
    )
    db.session.add(c) # prepare CREATE statement
    db.session.commit() # execute CREATE statement
    return jsonify(c.serialize())

@bp.route('/<int:id>', methods=['DELETE'])
def delete(id: int):
    c = Company.query.get_or_404(id)
    try:
        db.session.delete(c) # prepare DELETE statement
        db.session.commit() # execute DELETE statement
        return jsonify(True)
    except:
        # something went wrong :(
        return jsonify(False)
