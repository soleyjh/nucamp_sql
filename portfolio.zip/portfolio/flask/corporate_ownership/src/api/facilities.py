from flask import Blueprint

bp = Blueprint('facilities', __name__, url_prefix='/facilities')