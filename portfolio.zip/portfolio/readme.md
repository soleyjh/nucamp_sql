# Portfolio Project SQL Nucamp

At last! After 4 weeks of dealing with backend web servers and SQL this project represents the culmination of a whole lot of work. I've built a database for company relationships which utlizes flask to host this database as an API

## Getting Started 

Running this app locally will require Python 3.9+ and the following requirements.txt

alembic==1.6.5
Faker==8.5.1
Flask==2.0.1
Flask-Migrate==3.0.1
Flask-SQLAlchemy==2.5.1
psycopg2-binary==2.9.1
SQLAlchemy==1.4.17
